package com.hanwha.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hanwha.model.CoffeeDAO_mybatis;
import com.hanwha.model.GroupService;
import com.hanwha.model.GroupsDAO_mybatis;
import com.hanwha.model.GroupsVO;
import com.hanwha.model.MatchingService;
import com.hanwha.model.MatchingVO;
import com.hanwha.model.MemberDAO_mybatis;
import com.hanwha.model.MemberService;
import com.hanwha.model.MemberVO;
import com.hanwha.model.OrdersService;

@Controller
@RequestMapping
public class MainController {

	@Autowired
	MemberDAO_mybatis dao;

	@Autowired
	GroupsDAO_mybatis dao2;
	
	@Autowired
	CoffeeDAO_mybatis dao3;

	@Autowired
	MemberService service;
	
	@Autowired
	GroupService service3;
	
	@Autowired
	MatchingService service4;
	
	@Autowired
	OrdersService service5;
	
	
	// ���� ������ �����ֱ�
	// ��û�� �̸� = �ּ�â�̸�
	@RequestMapping("/mainpage")
	public void showMain() {
	}

	// �α��� �� �����ֱ�
	@RequestMapping(value = "/member/memberlogin", method = RequestMethod.GET)
	public String memberLoginGet() {
		return "/member/memberlogin";
	}

	// �α��� ��� ����
	@RequestMapping(value = "/member/memberlogin", method = RequestMethod.POST)
	public String memberLoginPost(MemberVO member, HttpServletRequest request, String member_id, String member_pw,HttpSession session) {

		ModelAndView mv = new ModelAndView();
		// DB�� �����ϴ� user���� üũ~~~service
		MemberVO member2 = service.getMember(member);
		mv.addObject("member", member2);
		

		 

		session.setAttribute("member", member2);
		if(session.getAttribute("member")==null) {
			return "redirect:/member/memberlogin";
		} else {
			return "redirect:../grouppage";
		}

	}

	// ȸ�� ���� �� �����ֱ�
	@RequestMapping(value = "/member/memberjoin", method = RequestMethod.GET)
	public String memberJoinGet() {
		return "/member/memberjoin";
	}

	// ȸ�� ���� ��� ����:
	@RequestMapping(value = "/member/memberjoin", method = RequestMethod.POST)
	public String memberJoinPost(MemberVO member) {
		dao.insertMember(member);
		return "/member/memberlogin";
	}

	// �׷� �߰� �� ���� �� �����ֱ�
	@RequestMapping("/grouppage")
	public String showGroup(Model model, HttpSession session) {
		MemberVO member = (MemberVO) session.getAttribute("member");
		model.addAttribute("groups", service3.selectall());
		return "/grouppage";
	}
	
	/*
	 * @RequestMapping("/groupdetailpage") public ModelAndView groupDetail(String
	 * group_name, HttpSession session) { ModelAndView mv = new ModelAndView();
	 * mv.addObject("group", service3.selectbygroup(group_name));
	 * mv.setViewName("/groupdetailpage"); return mv; }
	 */
	

	// �� �׷� �� �����ֱ�
	@RequestMapping(value = "/makegroup", method = RequestMethod.GET)
	public String makeGroupGet() {
		return "/makegroup";
	}

	
	// �� �׷� ���� ����
	@RequestMapping(value = "/makegroup", method = RequestMethod.POST)
	public String makeGroupPost(GroupsVO group, HttpSession session) {
		dao2.insertGroup(group);
		MatchingVO matching = new MatchingVO();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		matching.setGroup_name(group.getGroup_name());
		matching.setMember_id(member.getMember_id());
		
		service4.insertMatching(matching);
		
		return "redirect:/grouppage";
	}
	
	
	
	@RequestMapping(value="/setgroup")
	public String setGroupGet() {
		return "/setgroup";
	}
	//setgroup����� matching table�� insert. 
	@RequestMapping(value="/setgroup", method =RequestMethod.POST)
	public String setGroupPost(GroupsVO group, HttpSession session) {
		
		GroupsVO groupvo =dao2.selectbygroup(group);
		
		
		MatchingVO matching = new MatchingVO();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		matching.setGroup_name(groupvo.getGroup_name());
		matching.setMember_id(member.getMember_id());


		service4.insertMatching(matching);
		return "/setgroup";
	}

	
	//�ֹ� ������ �����ֱ�
	@RequestMapping(value="/orderpage")
	public ModelAndView orderGet(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		mv.addObject("member_id", member.getMember_id());
		mv.addObject("groups", service4.selectgroup()); //���� ���ǿ� ����� ����� ������ �׷���� �������
		mv.setViewName("/orderpage");
		return mv;
	}
	
	
	/*

	// �ֹ� �ϱ�
	@RequestMapping(value = "/orderpage", method= RequestMethod.POST)
	public String orderPage(OrderVO order, HttpSession session) {
		
		MemberVO member = (MemberVO) session.getAttribute("member");
		OrderVO order = new OrderVO();
		
		order.setMember_id(member.getMember_id());
		order.setGroup_name(/*����� �Է�);
		order.setMenu(/*����� �Է�);
		
		service5.insertOrder(order);
		return "/orderpage";
	
	}
	*/
	
	@RequestMapping(value="/result")
	public String result(Model model) {
		model.addAttribute("result", service5.selectall());
		return "/result";
	}

}
