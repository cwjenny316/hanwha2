package com.hanwha.model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class OrdersDAO_mybatis {
	@Autowired
	SqlSession session;
	
	public int insertOrders(OrdersVO order) {
		return session.insert("com.hanwha.orders.insert", order);
	}
	
	public List<OrdersVO> selectall(){
		return session.selectList("com.hanwha.orders.selectall");
	}

}
