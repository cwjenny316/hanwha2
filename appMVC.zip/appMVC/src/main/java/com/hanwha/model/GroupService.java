package com.hanwha.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GroupService {
	@Autowired
	GroupsDAO_mybatis dao;
	
	
	public int insertGroup(GroupsVO group) {
		return dao.insertGroup(group);
	}
	public List<GroupsVO> selectall(){
		return dao.selectall();
	}
	public GroupsVO selectbygroup(GroupsVO group) {
		return dao.selectbygroup(group);
	}

}
