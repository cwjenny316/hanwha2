package com.hanwha.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrdersService {
	@Autowired
	OrdersDAO_mybatis dao;
	
	public int insertOrders(OrdersVO order) {
		return dao.insertOrders(order);
	}
	
	public List<OrdersVO> selectall(){
		return dao.selectall();
	}
}
