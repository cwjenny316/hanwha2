package com.hanwha.model;



public class OrdersVO {
	String member_id;
	String group_name;
	String menu;
	
	
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	
	public OrdersVO() {
		super();
	}
	public OrdersVO(String member_id, String group_name, String menu) {
		super();
		this.member_id = member_id;
		this.group_name = group_name;
		this.menu = menu;
	}
	@Override
	public String toString() {
		return "OrderVO [member_id=" + member_id + ", group_name=" + group_name + ", menu=" + menu + "]";
	}
	
	
	
}
