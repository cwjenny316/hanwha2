package com.hanwha.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MatchingService {
	@Autowired
	MatchingDAO_mybatis dao;
	
	public int insertMatching(MatchingVO matching) {
		return dao.insertMatching(matching);
	}
	
	public List<MatchingVO> selectgroup() {
		return dao.selectgroup();
	}
}
