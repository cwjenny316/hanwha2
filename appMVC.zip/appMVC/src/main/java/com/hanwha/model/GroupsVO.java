package com.hanwha.model;

public class GroupsVO {
	String group_name;
	String group_url;
	String group_adress;
	
	public GroupsVO() {
		
	}
	public GroupsVO(String group_name, String group_url, String group_adress) {
		
		this.group_name = group_name;
		this.group_url = group_url;
		this.group_adress = group_adress;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	public String getGroup_url() {
		return group_url;
	}
	public void setGroup_url(String group_url) {
		this.group_url = group_url;
	}
	public String getGroup_adress() {
		return group_adress;
	}
	public void setGroup_adress(String group_adress) {
		this.group_adress = group_adress;
	}
	@Override
	public String toString() {
		return "GroupsVO [group_name=" + group_name + ", group_url=" + group_url + ", group_adress=" + group_adress
				+ "]";
	}
	
	
}
