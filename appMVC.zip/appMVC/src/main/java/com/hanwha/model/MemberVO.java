package com.hanwha.model;

import org.springframework.web.multipart.MultipartFile;

public class MemberVO {
	String member_id;
	String member_pw;
	String card_num;
	int pay;
	

	
	public MemberVO() {
		
	}
	
	public MemberVO(String member_id, String member_pw, String card_num, int pay) {
		this.member_id = member_id;
		this.member_pw = member_pw;
		this.card_num = card_num;
		this.pay=pay;
	}
	

	public String getMember_id() {
		return member_id;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getMember_pw() {
		return member_pw;
	}

	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}

	public String getCard_num() {
		return card_num;
	}

	public void setCard_num(String card_num) {
		this.card_num = card_num;
	}

	public int getPay() {
		return pay;
	}

	public void setPay(int pay) {
		this.pay = pay;
	}

	@Override
	public String toString() {
		return "MemberVO [member_id=" + member_id + ", member_pw=" + member_pw + ", card_num=" + card_num + ", pay="
				+ pay + "]";
	}
	
	

	
}
