package com.hanwha.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class GroupsDAO_mybatis {
	@Autowired
	SqlSession session;
	
	
	public int insertGroup(GroupsVO group) {
		return session.insert("com.hanwha.groups.insert", group);
	}
	
	public List<GroupsVO> selectall(){
		return session.selectList("com.hanwha.groups.selectall");
	}

	public GroupsVO selectbygroup(GroupsVO group) {
		return session.selectOne("com.hanwha.groups.selectbygroup");
	}


}
