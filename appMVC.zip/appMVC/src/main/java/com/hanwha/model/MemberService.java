package com.hanwha.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberService {
		
		@Autowired
		MemberDAO_mybatis dao;
		
		
		public int insertMember(MemberVO member) {
			return dao.insertMember(member);
		}
		
		public MemberVO getMember(MemberVO member) {
			return dao.getMember(member);
		}
		
		public List<MemberVO> selectall(){
			return dao.selectall();
		}
		
	

}
