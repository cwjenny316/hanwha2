package com.hanwha.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO_mybatis {
	@Autowired
	SqlSession session;
	
	
	public int insertMember(MemberVO member) {
		return session.insert("com.hanwha.insert", member);
	}
	
	public MemberVO getMember(MemberVO member) {
		return session.selectOne("com.hanwha.select",member);
	}
	
	public List<MemberVO> selectall(){
		return session.selectList("com.hanwha.selectall");
	}
	


}
