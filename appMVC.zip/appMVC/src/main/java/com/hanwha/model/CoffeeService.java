package com.hanwha.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CoffeeService {
	@Autowired
	CoffeeDAO_mybatis dao;	
	
	
	public List<CoffeeVO> selectall() {
		 return dao.selectall();
	}
	
}
